# l'importation des packages de scraping et http et rendering
import requests
from django.shortcuts import render
from bs4 import BeautifulSoup

# fetch tout les marque des smartphone dans jumia et retourne sa liste de string
def get_brand_options():
    url = "https://www.jumia.com.tn/smartphones/"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    parent_1 = soup.find('div', {'id': 'jm'})
    parent_2 = parent_1.find('main', {'class': 'has-b2top -pts'})
    parent_3 = parent_2.find('div', {'class': '-phs -pvxs -df -d-co -h-168 -oya -sc'})
    options = []
    for option in parent_3.findAll('a', {'class': 'fk-cb -me-start -fsh0'}):
        options.append(option.get('data-value'))
        print(options)
    return options

# sraping tout les produits dans tout les pages des smartphone dans jumia et retourne sa liste de produits avec l'id , nom image , lien ...
# get les valeurs de formulaire pour filtrer l'url de recherche scraping
# passe les valeurs a la template index.html (products : les produits , formulaire valeurs current : pour les enregistrer, les marques : pour l'ajouter a la select option)
def home(request):
    brand_input = request.GET.get('brand_input')
    price_input = request.GET.get('price_input')
    brand_options = get_brand_options()
    products = []

    if not brand_input or brand_input.lower() == 'all':
        if not price_input:
            url = "https://www.jumia.com.tn/smartphones/?page="
        else:
            url = "https://www.jumia.com.tn/smartphones/?price=15-" + price_input +"&page="
    else:
        if not price_input:
            url = "https://www.jumia.com.tn/smartphones/" + brand_input.lower() + "/?page="
        else:
            url = "https://www.jumia.com.tn/smartphones/" + brand_input.lower() + "/?price=15-" + price_input +"&page="

    for page in range(1, 15): 
        url = url + str(page)
        response = requests.get(url)
        soup = BeautifulSoup(response.content, 'html.parser')

        for product in soup.findAll('article', {'class': 'prd _fb col c-prd'}):
            name = limit_text(product.find('a', {'class': 'core'}).get('data-name'), 48)
            price = product.find('div', {'class': 'prc'}).get_text()
            image = product.find('img', {'class': 'img'}).get('data-src')
            brand = product.find('a', {'class': 'core'}).get('data-brand')
            data = product.find('a', {'class': 'core'}).get('data-category')
            id = product.find('a', {'class': 'core'}).get('data-id')
            link = "https://www.jumia.com.tn" + product.find('a', {'class': 'core'}).get('href')
            products.append({'name': name, 'price': price, 'image': image, 'brand': brand, 'link': link, 'id': id, 'data': data})
    return render(request, 'index.html', {'products': products, 'brand_options': brand_options, 'brand_input': brand_input, 'price_input': price_input})
    

# fonction pour minimiser le text a un nombre des lettres specific , pour les nom des produits long
def limit_text(text, limit):
    if len(text) > limit:
        return text[:limit-3] + '...'
    else:
        return text